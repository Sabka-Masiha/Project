package com.capstore.admin.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="productdetail")
public class ProductDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="productid")
	private int productId;
	@Column(name="productname")
	private String productName;
	@Column(name="productprice")
	private int productPrice;
	@Column(name="productquantity")
	private int productQuantity;
	private int discountOffered;
	private String productCategory;
	private String productType;
	private String productBrand;
	private String productModel;
	private String productFeatures;
	private String productRating;
	private String productFeedback;
	
	@ManyToOne(targetEntity = CartDTO.class, fetch = FetchType.LAZY)
	private CartDTO carts;
	@ManyToOne(targetEntity = MerchantDTO.class, fetch = FetchType.LAZY)
	private List<MerchantDTO> merchants;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public int getDiscountOffered() {
		return discountOffered;
	}

	public void setDiscountOffered(int discountOffered) {
		this.discountOffered = discountOffered;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductBrand() {
		return productBrand;
	}

	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}

	public String getProductModel() {
		return productModel;
	}

	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}

	public String getProductFeatures() {
		return productFeatures;
	}

	public void setProductFeatures(String productFeatures) {
		this.productFeatures = productFeatures;
	}

	public String getProductRating() {
		return productRating;
	}

	public void setProductRating(String productRating) {
		this.productRating = productRating;
	}

	public String getProductFeedback() {
		return productFeedback;
	}

	public void setProductFeedback(String productFeedback) {
		this.productFeedback = productFeedback;
	}

	public List<MerchantDTO> getMerchants() {
		return merchants;
	}

	public void setMerchants(List<MerchantDTO> merchantDTO) {
		this.merchants = merchantDTO;
	}

	
	
	
	
}
