package com.capstore.admin.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="offer")
public class OfferDTO {

	@Id
	@Column(name="offerdescription")
	private String offerDescription;
	@Column(name="offerstartdate")
	private Date offerStartDate;
	@Column(name="offerenddate")
	private Date offerEndDate;
	@Column(name="discountoffered")
	private int discountOffered;
	
	@ManyToOne(targetEntity=MerchantDTO.class, fetch=FetchType.LAZY)
	private MerchantDTO merchants;
	
	@OneToOne(targetEntity=ProductDTO.class,fetch = FetchType.LAZY)
	private ProductDTO product;
	
	public String getOfferDescription() {
		return offerDescription;
	}
	public void setOfferDescription(String offerDescription) {
		this.offerDescription = offerDescription;
	}
	public Date getOfferStartDate() {
		return offerStartDate;
	}
	public void setOfferStartDate(Date offerStartDate) {
		this.offerStartDate = offerStartDate;
	}
	public Date getEndStartDate() {
		return offerEndDate;
	}
	public void setEndStartDate(Date endStartDate) {
		this.offerEndDate = endStartDate;
	}
	public int getDiscountOffered() {
		return discountOffered;
	}
	public void setDiscountOffered(int discountOffered) {
		this.discountOffered = discountOffered;
	}
	public MerchantDTO getMerchant() {
		return merchants;
	}
	public void setMerchant(MerchantDTO merchant) {
		this.merchants = merchant;
	}
	public ProductDTO getProduct() {
		return product;
	}
	public void setProduct(ProductDTO product) {
		this.product = product;
	}
	
	
	
}
